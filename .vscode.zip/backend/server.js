const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors({ origin: '*' })); // allow all origins
app.use(express.json());

// Optional extra safety for CORS headers
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

const DATA_DIR = path.join(__dirname, 'data');

app.get('/airports', (req, res) => {
  try {
    const raw = fs.readFileSync(path.join(DATA_DIR, 'airports.json'), 'utf8');
    res.setHeader('Content-Type', 'application/json');
    res.send(raw);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Could not read airports data' });
  }
});

app.get('/edges', (req, res) => {
  try {
    const raw = fs.readFileSync(path.join(DATA_DIR, 'edges.json'), 'utf8');
    res.setHeader('Content-Type', 'application/json');
    res.send(raw);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Could not read edges data' });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`✅ Backend running at http://127.0.0.1:${PORT}`);
});
