const BASE_URL = "http://localhost:5000";

let map, planeMarker, flightLine;
let airports = [], edges = [];

// --- Global Constants for Time Calculation ---
const AVERAGE_SPEED_KMPH = 800; // Average cruising speed of a passenger jet
const BUFFER_HOURS = 0.5; // 30 minutes for takeoff/landing pr  ocedures

// =================================================================
// 1. DATA FETCHING & SETUP
// =================================================================

// read params from URL (passed from find.html)
function getParams() {
    const p = new URLSearchParams(window.location.search);
    return {
        from: p.get('from'),
        to: p.get('to'),
        ticketClass: p.get('class'),
        cost: p.get('cost'),
        date: p.get('date')
    };
}

// Fetch data from the external backend API
async function fetchData() {
    try {
        const [aRes, eRes] = await Promise.all([
            fetch(`${BASE_URL}/airports`), 
            fetch(`${BASE_URL}/edges`)
        ]);
        airports = await aRes.json();
        edges = await eRes.json();
    } catch (err) {
        console.error("Backend Data Fetch Error:", err);
        // Using a custom modal/message is preferred over alert() in production, 
        // but alert() is used here for simplicity.
        alert('Could not load backend data. Make sure backend is running at http://localhost:5000');
        throw err;
    }
}

// Initialize the Leaflet map focused on the India region
function initMap() {
    map = L.map('map', { zoomControl: true }).setView([20, 78], 5);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
}

// Helper to find airport object by ID
function getAirport(id) {
    return airports.find(a => String(a.id) === String(id));
}

// =================================================================
// 2. DSA CORE: DIJKSTRA'S ALGORITHM
// =================================================================

function dijkstra(src, dst) {
    const ids = airports.map(a => a.id);
    const dist = {}, used = {}, parent = {};
    ids.forEach(id => { dist[id] = Infinity; used[id] = false; parent[id] = null; });
    dist[src] = 0;

    for (let i = 0; i < ids.length; i++) {
        let v = null;
        
        // Find the unvisited node 'v' with the smallest distance
        for (let id of ids) {
            if (!used[id] && (v === null || dist[id] < dist[v])) v = id;
        }

        if (v === null || dist[v] === Infinity) break;
        used[v] = true;

        // Relax edges from node 'v'
        edges.forEach(e => {
            // Check both directions (assuming undirected graph or checking if 'v' is 'u' or 'v' in the edge object)
            // The edge weight (e.w) represents the distance/cost being minimized.
            if (e.u === v) {
                if (dist[v] + e.w < dist[e.v]) { dist[e.v] = dist[v] + e.w; parent[e.v] = v; }
            } else if (e.v === v) {
                if (dist[v] + e.w < dist[e.u]) { dist[e.u] = dist[v] + e.w; parent[e.u] = v; }
            }
        });
    }

    if (dist[dst] === Infinity) return { path: [], distance: 0 };
    
    // Path reconstruction
    const path = [];
    let cur = dst;
    while (cur !== null) { path.push(cur); cur = parent[cur]; }
    path.reverse();
    
    return { path, distance: Math.round(dist[dst]) };
}

// =================================================================
// 3. TIME & DURATION CALCULATIONS
// =================================================================

/**
 * Calculates total flight duration in hours (including buffer).
 * Uses the shortest distance found by Dijkstra's algorithm.
 */
function calculateDurationHours(distanceKm) {
    if (distanceKm === 0) return 0;
    // Calculation: (Distance / Average Speed) + Fixed Buffer
    return (distanceKm / AVERAGE_SPEED_KMPH) + BUFFER_HOURS;
}

/**
 * Formats total hours into a readable string (e.g., "3 hr 45 min").
 */
function formatDuration(totalHours) {
    if (totalHours === 0) return '0 min';
    const hours = Math.floor(totalHours);
    const minutes = Math.round((totalHours - hours) * 60);
    
    let parts = [];
    if (hours > 0) parts.push(`${hours} hr`);
    if (minutes > 0) parts.push(`${minutes} min`);
    
    return parts.join(' ');
}

/**
 * Calculates the arrival time given a departure time and duration.
 */
function calculateArrivalTime(departureTime, totalHours) {
    const [depHour, depMinute] = departureTime.split(':').map(Number);
    const depTotalMinutes = depHour * 60 + depMinute;
    
    const durationMinutes = Math.round(totalHours * 60);
    const arrivalTotalMinutes = depTotalMinutes + durationMinutes;

    // Handles wrap-around (e.g., 23:00 + 4 hours = 03:00 next day)
    const arrivalMinute = arrivalTotalMinutes % 60;
    const arrivalHour = Math.floor(arrivalTotalMinutes / 60) % 24;

    const hourStr = String(arrivalHour).padStart(2, '0');
    const minuteStr = String(arrivalMinute).padStart(2, '0');
    
    return `${hourStr}:${minuteStr}`;
}


// =================================================================
// 4. MAP VISUALIZATION & UI UPDATES
// =================================================================

// Draw markers and the polyline path on the Leaflet map
function drawPath(path) {
    if (flightLine) map.removeLayer(flightLine);
    if (planeMarker) map.removeLayer(planeMarker);

    const latlngs = path.map(id => {
        const a = getAirport(id);
        return [a.lat, a.lng];
    });

    flightLine = L.polyline(latlngs, { color: '#007bff', weight: 5, opacity: 0.9 }).addTo(map);
    map.fitBounds(flightLine.getBounds().pad(0.5));

    // Add airport markers
    path.forEach((id, idx) => {
        const a = getAirport(id);
        const isEnd = (idx === 0 || idx === path.length-1);
        L.circleMarker([a.lat, a.lng], {
            radius: isEnd ? 9 : 6,
            fillColor: isEnd ? '#ffd700' : '#ffffff',
            color: '#004085',
            weight: 2,
            fillOpacity: 1
        }).addTo(map).bindPopup(`${a.name} ${idx===0? '(Start)': idx===path.length-1? '(End)': '(Stop)'}`);
    });

    animatePlaneAlong(latlngs, 9000); // 9 seconds animation
}

// Animate the plane marker along the calculated route
function animatePlaneAlong(latlngs, totalMs) {
    planeMarker = L.marker(latlngs[0], {
        icon: L.icon({ iconUrl: 'https://cdn-icons-png.flaticon.com/512/684/684908.png', iconSize: [50,50], iconAnchor:[25,25] })
    }).addTo(map);

    const segments = latlngs.length - 1;
    if (segments <= 0) return;
    const msPerSegment = totalMs / segments;
    let segIndex = 0;

    function moveSegment() {
        if (segIndex >= segments) return;
        const start = latlngs[segIndex];
        const end = latlngs[segIndex+1];
        const frames = Math.max(40, Math.round(msPerSegment / 16)); // ~60fps target
        let frame = 0;
        const deltaLat = (end[0] - start[0]) / frames;
        const deltaLng = (end[1] - start[1]) / frames;

        const step = () => {
            frame++;
            const lat = start[0] + deltaLat * frame;
            const lng = start[1] + deltaLng * frame;
            planeMarker.setLatLng([lat, lng]);

            // Rotate plane along bearing
            const angle = Math.atan2(end[1]-start[1], end[0]-start[0]) * 180 / Math.PI;
            if (planeMarker._icon) planeMarker._icon.style.transform = `rotate(${angle}deg)`;

            if (frame < frames) requestAnimationFrame(step);
            else {
                segIndex++;
                setTimeout(moveSegment, 180); // Small pause at nodes (layover simulation)
            }
        };
        requestAnimationFrame(step);
    }
    moveSegment();
}

// Populate the summary list in the result.html page
function updateUI(params, shortest) {
    const fromA = getAirport(params.from);
    const toA = getAirport(params.to);

    // Dynamic Time Calculation using the shortest distance
    const totalDurationHours = calculateDurationHours(shortest.distance);
    const formattedDuration = formatDuration(totalDurationHours);
    const departureTime = '08:00'; 
    const arrivalTime = calculateArrivalTime(departureTime, totalDurationHours);

    const infoPanel = document.querySelector('.info-panel');
    infoPanel.innerHTML = `
        <h3>Flight Info</h3>
        <p><strong>From:</strong> ${fromA.name}</p>
        <p><strong>To:</strong> ${toA.name}</p>
        <p><strong>Stops:</strong> ${Math.max(shortest.path.length - 2, 0)}</p>
    `;

    document.getElementById('distance').textContent = `${shortest.distance} km`;
    document.getElementById('stops').textContent = `${Math.max(shortest.path.length - 2, 0)}`;
    
    // --- Display Fix ---
    document.getElementById('duration').textContent = formattedDuration; 
    // -------------------

    document.getElementById('departure').textContent = departureTime;
    document.getElementById('arrival').textContent = arrivalTime;
    document.getElementById('class').textContent = params.ticketClass || 'Economy';
    document.getElementById('cost').textContent = params.cost ? `₹${params.cost}` : '—';
    document.getElementById('date').textContent = params.date || '—';
}

// =================================================================
// 5. MAIN EXECUTION
// =================================================================

// Main function run on page load
//This is the master function that runs everything.
async function main() {
    const params = getParams();
    if (!params.from || !params.to) { 
        alert('Missing parameters. Please select cities from the Find page.'); 
        return; 
    }

    try {
        await fetchData();
    } catch (e) {
        // Stop execution if data fetch failed (alert thrown in fetchData)
        return; 
    }
    
    initMap();

    // Run the core DSA algorithm
    const shortest = dijkstra(params.from, params.to);
    
    if (!shortest.path || shortest.path.length <= 1) {
        alert('No path found between selected airports, or data is missing.');
        return;
    }

    // Update the UI with results
    drawPath(shortest.path);
    updateUI(params, shortest);
}

window.addEventListener('load', main);