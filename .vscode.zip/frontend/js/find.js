const BASE_URL = "http://localhost:5000";

// price base multipliers (example)
const PRICE_BASE = 2000; // economy baseline

// DROPDOWNS CITY LOADING
async function loadAirportsIntoSelects() {
  try {
    const res = await fetch(`${BASE_URL}/airports`); 
    const airports = await res.json();// TAKES DATA FROM THE SERVER AND COVERTS IT TO JSON

    const fromSelect = document.getElementById('fromCity');
    const toSelect = document.getElementById('toCity');

    airports.forEach(apt => {
      const o1 = document.createElement('option');
      o1.value = apt.id;// sets the value attribute of the option element to the airport's ID
      o1.text = apt.name;// sets the displayed text of the option element to the airport's name
      fromSelect.appendChild(o1);// adds the option element to the "fromCity" select dropdown

      const o2 = document.createElement('option');
      o2.value = apt.id;
      o2.text = apt.name;
      toSelect.appendChild(o2);
    });
// set defaults if possible //
    if (airports.length >= 2) {
      fromSelect.selectedIndex = 0;
      toSelect.selectedIndex = 1;
    }
  } 
  //
  catch (err) {
    console.error(err);
    alert('Could not load airports. Ensure backend is running (http://localhost:5000).');
  }
}

function updatePricePreview() {
  const cls = document.getElementById('classSelect').value;// get selected class
  let price = PRICE_BASE;
  if (cls === 'economy') price = PRICE_BASE;
  else if (cls === 'business') price = Math.round(PRICE_BASE * 2.6);
  else if (cls === 'first') price = Math.round(PRICE_BASE * 4.5);
  document.getElementById('ticketCost').value = price;// update hidden cost input
}

document.getElementById('classSelect').addEventListener('change', updatePricePreview);// update price on class change
document.getElementById('dateSelect').addEventListener('change', ()=>{/* future: validate date */});// placeholder for date validation
// FIND BUTTON CLICK HANDLER
// on click, validate inputs and redirect to results page with query params
document.getElementById('findBtn').addEventListener('click', (e)=>{
  e.preventDefault();
  const from = document.getElementById('fromCity').value;// get selected origin
  const to = document.getElementById('toCity').value;// get selected destination
  const ticketClass = document.getElementById('classSelect').value;// get selected class
  const date = document.getElementById('dateSelect').value || '';
  const cost = document.getElementById('ticketCost').value || '';

  if (!from || !to) { alert('Please select both origin and destination'); return; }
  if (from === to) { alert('Origin and destination must be different'); return; }

  // redirect with safe encoding
  const params = new URLSearchParams({ from, to, class: ticketClass, cost, date });// create query params // redirect to results page
  window.location.href = `result.html?${params.toString()}`;// redirect to results page
});

// init
window.addEventListener('load', async () => {
  await loadAirportsIntoSelects();// load airport data into dropdowns
  updatePricePreview();// set initial price preview
});
