# Airline Shortest Path Finder

## Setup

### Backend
1. Open terminal and go to `backend` folder.
2. Run:
npm install
npm start

arduino
Copy code
Backend will run at `http://localhost:5000`

### Frontend
1. Serve `frontend` folder using Live Server (VS Code) or a static server:
cd frontend
npx serve

pgsql
Copy code
or use VS Code Live Server. Open the URL shown (e.g., `http://127.0.0.1:5000` for serve or `http://127.0.0.1:5500` for Live Server).
2. Go to `index.html` → click **Get Started** → Fill `find.html` → click **Find Shortest Path**.

## Notes
- Backend serves airports and edges JSON.
- Frontend computes shortest path using Dijkstra and displays the route.
- All distances are sample values for demo/visualization.